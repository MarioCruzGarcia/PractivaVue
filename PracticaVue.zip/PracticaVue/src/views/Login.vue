<script setup>
import axios from 'axios'
import { onBeforeMount, ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const users = ref([])
const name = ref('')
const username = ref('')
const loggedIn = ref(false)

async function leerApi() {
  const response = await axios.get("https://jsonplaceholder.typicode.com/users")
  users.value = response.data
}

function onSubmit() {
  const user = users.value.find(u => u.name === name.value && u.username === username.value)
  if (user) {
    loggedIn.value = true;
    setTimeout(() => {
      router.push({ path: '/Index' });
    }, 1000); 
  } else {
    loggedIn.value = false;
  }
}


function handleKeyPress() {
  onSubmit();
}

onBeforeMount(leerApi)

</script>



<template>
  <div>
    <div v-if="!loggedIn" class="login-box">
      <p>Login</p>
      <form @submit.prevent="onSubmit">
        <div class="user-box">
          <input v-model="name" required name="" type="text" @keydown.ctrl.alt.enter="handleKeyPress">
          <label>Name</label>
        </div>
        <div class="user-box">
          <input v-model="username" required name="" type="text" @keydown.ctrl.alt.enter="handleKeyPress">
          <label>Username</label>
        </div>
        <button type="submit">Inicio Sesion</button>
      </form>
    </div>
    <div v-else class="login-success">
      <p>Inicio de sesión correcto</p>
    </div>
  </div>
</template>


<style scoped>
.login-success {
  background-color: #4CAF50; 
  color: white;
  padding: 20px;
  margin: 20px auto;
  width: 200px;
  text-align: center;
}
.login-box {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 400px;
  padding: 40px;
  margin: 20px auto;
  transform: translate(-50%, -55%);
  background: rgba(0,0,0,.9);
  box-sizing: border-box;
  box-shadow: 0 15px 25px rgba(0,0,0,.6);
  border-radius: 10px;
}

.login-box p:first-child {
  margin: 0 0 30px;
  padding: 0;
  color: #fff;
  text-align: center;
  font-size: 1.5rem;
  font-weight: bold;
  letter-spacing: 1px;
}

.login-box .user-box {
  position: relative;
}

.login-box .user-box input {
  width: 100%;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  margin-bottom: 30px;
  border: none;
  border-bottom: 1px solid #fff;
  outline: none;
  background: transparent;
}

.login-box .user-box label {
  position: absolute;
  top: 0;
  left: 0;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  pointer-events: none;
  transition: .5s;
}

.login-box .user-box input:focus ~ label,
.login-box .user-box input:valid ~ label {
  top: -20px;
  left: 0;
  color: #fff;
  font-size: 12px;
}

.login-box p:last-child {
  color: #705858;
  font-size: 14px;
}


button {
 --glow-color: rgb(255, 255, 255);
 --glow-spread-color: rgba(106, 102, 107, 0.781);
 --enhanced-glow-color: rgb(72, 67, 74);
 --btn-color: rgb(119, 116, 116);
 border: .25em solid var(--glow-color);
 padding: 1em 3em;
 color: var(--glow-color);
 font-size: 15px;
 font-weight: bold;
 background-color: var(--btn-color);
 border-radius: 1em;
 outline: none;
 box-shadow: 0 0 1em .25em var(--glow-color),
        0 0 4em 1em var(--glow-spread-color),
        inset 0 0 .75em .25em var(--glow-color);
 text-shadow: 0 0 .5em var(--glow-color);
 position: relative;
 transition: all 0.3s;
}

button::after {
 pointer-events: none;
 content: "";
 position: absolute;
 top: 120%;
 left: 0;
 height: 100%;
 width: 100%;
 background-color: var(--glow-spread-color);
 filter: blur(2em);
 opacity: .7;
 transform: perspective(1.5em) rotateX(35deg) scale(1, .6);
}

button:hover {
 color: var(--btn-color);
 background-color: var(--glow-color);
 box-shadow: 0 0 1em .25em var(--glow-color),
        0 0 4em 2em var(--glow-spread-color),
        inset 0 0 .75em .25em var(--glow-color);
}

button:active {
 box-shadow: 0 0 0.6em .25em var(--glow-color),
        0 0 2.5em 2em var(--glow-spread-color),
        inset 0 0 .5em .25em var(--glow-color);
}


</style>

