<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>
 
<template>
    
  <RouterLink to="/"></RouterLink>
  <RouterLink to="/Index"></RouterLink>
  

  <RouterView/>
  
 
</template>
 
<style scoped>
 
</style>